/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#171918',
    tint: '#247f75',

    // Core surfaces
    background: '#f1f1ed',
    foreground: '#171918',

    // Cards / elevated surfaces
    card: '#e7e8e3',
    cardForeground: '#171918',

    // Primary action color (buttons, links, active states)
    primary: '#247f75',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e5e7e1',
    secondaryForeground: '#272b29',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#e7e8e3',
    mutedForeground: '#777d78',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#dce9e4',
    accentForeground: '#174c45',

    // Destructive actions (delete, error states)
    destructive: '#b6423c',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#d8dbd5',
    input: '#d8dbd5',
  },

  dark: {
    text: '#f3f4ef',
    tint: '#7cc7b9',
    background: '#151817',
    foreground: '#f3f4ef',
    card: '#202523',
    cardForeground: '#f3f4ef',
    primary: '#7cc7b9',
    primaryForeground: '#102320',
    secondary: '#282e2b',
    secondaryForeground: '#e8ebe6',
    muted: '#252b28',
    mutedForeground: '#a0a8a2',
    accent: '#283d37',
    accentForeground: '#b6e4d9',
    destructive: '#ed8178',
    destructiveForeground: '#25100e',
    border: '#343c38',
    input: '#343c38',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
