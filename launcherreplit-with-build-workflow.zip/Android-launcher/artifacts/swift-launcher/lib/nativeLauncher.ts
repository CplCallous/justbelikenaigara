import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo-modules-core';
import type { LauncherApp } from '@/data/launcher';

type NativeLauncherModule = {
  getInstalledApps(): Promise<LauncherApp[]>;
  launchApp(packageName: string): Promise<boolean>;
  openAppInfo(packageName: string): Promise<void>;
  uninstallApp(packageName: string): Promise<void>;
  openHomeSettings(): Promise<void>;
  openNotificationAccessSettings(): Promise<void>;
  hasNotificationAccess(): boolean;
  getNotificationPreviews(): Record<string, string>;
  getActiveMediaInfo(): { packageName: string; title: string; artist: string; playing: boolean } | null;
  controlMedia(action: 'play' | 'pause' | 'next' | 'previous'): Promise<boolean>;
  setNotificationPreviewCollection(enabled: boolean): Promise<void>;
  openUsageAccessSettings(): Promise<void>;
  hasUsageAccess(): boolean;
  getMostUsedApps(): Promise<string[]>;
  getTodayUsageSummary(): Promise<{ packageName: string; foregroundMs: number }[]>;
  getUpcomingEvents(limit: number): Promise<{ title: string; begin: number; end: number; location: string; allDay: boolean }[]>;
  openAccessibilitySettings(): Promise<void>;
  getAppIcon(packageName: string): Promise<string | null>;
  expandNotificationShade(): Promise<boolean>;
  hasLockService(): boolean;
  lockScreen(): Promise<boolean>;
};

export const nativeLauncher =
  Platform.OS === 'android'
    ? requireOptionalNativeModule<NativeLauncherModule>('SwiftLauncher')
    : null;

export const isNativeLauncherAvailable = Boolean(nativeLauncher);
