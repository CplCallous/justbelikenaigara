export type LauncherApp = {
  packageName: string;
  name: string;
};

export type LauncherFolder = {
  id: string;
  name: string;
  appIds: string[];
  hidden: boolean;
};

export const featureGroups = [
  {
    title: 'Home screen',
    description: 'Keep the home screen focused and quick.',
    features: [
      { key: 'showIcons', label: 'Show app icons', detail: 'Display an icon beside each app name.' },
      { key: 'suggestions', label: 'App suggestions', detail: 'Surface frequently used apps below favorites.', access: 'Usage access' },
      { key: 'notificationPreviews', label: 'Notification previews', detail: 'Show the latest notification under its app.', access: 'Notification access' },
      { key: 'notificationSummary', label: 'Notification summary', detail: 'Show a compact notification summary.' },
      { key: 'pullDownShade', label: 'Pull down for notifications', detail: 'Open the Android notification shade from the home screen.', access: 'System API; device support varies' },
      { key: 'hideStatusBar', label: 'Hide status bar', detail: 'Use more of the screen for your apps.' },
      { key: 'leftHanded', label: 'Left-hand mode', detail: 'Move the alphabet scrubber to the left edge.' },
      { key: 'landscape', label: 'Landscape layout', detail: 'Allow the home screen to rotate.' },
    ],
  },
  {
    title: 'Productivity',
    description: 'Put useful tools and updates in reach.',
    features: [
      { key: 'calendarAgenda', label: 'Calendar agenda', detail: 'Show the next event on your home screen.', access: 'Calendar access' },
      { key: 'calendarPreview', label: 'Calendar preview', detail: 'Preview upcoming events in the app list.', access: 'Calendar access' },
      { key: 'weather', label: 'Weather forecast', detail: 'Show local conditions and a forecast.', access: 'Location access' },
      { key: 'mediaPlayer', label: 'Media player', detail: 'Show playback controls in the home list.', access: 'Notification access' },
      { key: 'musicApps', label: 'Music apps', detail: 'Surface music apps when headphones connect.', access: 'Bluetooth access' },
      { key: 'quickReplies', label: 'Quick replies', detail: 'Reply to supported messages from home.', access: 'Notification access' },
      { key: 'digitalWellbeing', label: 'Digital wellbeing', detail: 'See usage reminders and app habits.' },
      { key: 'usageBreaker', label: 'Usage breaker', detail: 'Get reminders to take a break.', access: 'Usage access' },
      { key: 'calculator', label: 'Built-in calculator', detail: 'Open a quick calculator from the app list.' },
    ],
  },
  {
    title: 'Personalization',
    description: 'Choose what the launcher looks and feels like.',
    features: [
      { key: 'iconPacks', label: 'Icon pack support', detail: 'Apply icons from a compatible Android icon pack.', access: 'Android icon pack integration' },
      { key: 'customFont', label: 'Custom font', detail: 'Use a font file or choose a built-in font.' },
      { key: 'homeWidgets', label: 'Home-screen widgets', detail: 'Host Android widgets on the home screen.', access: 'Android widget host' },
      { key: 'folders', label: 'Folders', detail: 'Group apps into folders.' },
      { key: 'swipeActions', label: 'Swipe actions', detail: 'Assign a quick action to an app swipe.' },
      { key: 'popUps', label: 'App pop-ups', detail: 'Open supported app actions in a pop-up.' },
      { key: 'dualApps', label: 'Dual-app support', detail: 'Show installed work and personal app copies.' },
    ],
  },
  {
    title: 'Privacy & security',
    description: 'Protect app access and keep private folders out of view.',
    features: [
      { key: 'appPassword', label: 'PIN-protect selected apps', detail: 'Ask for your PIN before opening a locked app.' },
      { key: 'doubleTapToLock', label: 'Double-tap to lock', detail: 'Lock the screen with a double tap.', access: 'Accessibility service' },
      { key: 'quickLock', label: 'Quick-lock gesture', detail: 'Add a gesture that locks the screen.', access: 'Accessibility service' },
      { key: 'bluetoothShortcuts', label: 'Bluetooth shortcuts', detail: 'Show selected apps while a device is connected.', access: 'Bluetooth access' },
    ],
  },
  {
    title: 'Search & backup',
    description: 'Keep your data portable and your tools close.',
    features: [
      { key: 'sesameSearch', label: 'Sesame search', detail: 'Connect to the Sesame search app if installed.' },
      { key: 'googleNews', label: 'Google News feed', detail: 'Open your Google News feed from home.' },
      { key: 'backupRestore', label: 'Backup & restore', detail: 'Copy launcher settings to or from the clipboard.' },
    ],
  },
] as const;

export type FeatureKey = (typeof featureGroups)[number]['features'][number]['key'];
export type FeatureSettings = Record<FeatureKey, boolean>;

export const defaultSettings: FeatureSettings = {
  showIcons: true,
  suggestions: false,
  notificationPreviews: false,
  notificationSummary: false,
  pullDownShade: false,
  hideStatusBar: false,
  leftHanded: false,
  landscape: false,
  calendarAgenda: false,
  calendarPreview: false,
  weather: false,
  mediaPlayer: false,
  musicApps: false,
  quickReplies: false,
  digitalWellbeing: false,
  usageBreaker: false,
  calculator: true,
  iconPacks: false,
  customFont: false,
  homeWidgets: false,
  folders: true,
  swipeActions: false,
  popUps: false,
  dualApps: false,
  appPassword: false,
  doubleTapToLock: false,
  quickLock: false,
  bluetoothShortcuts: false,
  sesameSearch: false,
  googleNews: false,
  backupRestore: true,
};

export type LauncherData = {
  settings: FeatureSettings;
  favorites: string[];
  favoritesConfigured: boolean;
  hiddenApps: string[];
  renamedApps: Record<string, string>;
  customIcons: Record<string, string>;
  lockedApps: string[];
  folders: LauncherFolder[];
  clockSize?: number;
  customFontUri?: string;
  customFontFamily?: string;
};

export const defaultLauncherData: LauncherData = {
  settings: defaultSettings,
  favorites: ['demo.camera', 'demo.chrome', 'demo.brave', 'demo.calendar', 'demo.files'],
  favoritesConfigured: false,
  hiddenApps: [],
  renamedApps: {},
  customIcons: {},
  lockedApps: [],
  folders: [],
  clockSize: 47,
};

export const demoApps: LauncherApp[] = [
  { packageName: 'demo.camera', name: 'Camera' },
  { packageName: 'demo.chrome', name: 'Chrome' },
  { packageName: 'demo.brave', name: 'Brave' },
  { packageName: 'demo.calendar', name: 'Calendar' },
  { packageName: 'demo.files', name: 'Files' },
  { packageName: 'demo.gmail', name: 'Gmail' },
  { packageName: 'demo.maps', name: 'Maps' },
  { packageName: 'demo.messages', name: 'Messages' },
  { packageName: 'demo.music', name: 'Music' },
  { packageName: 'demo.notes', name: 'Notes' },
  { packageName: 'demo.phone', name: 'Phone' },
  { packageName: 'demo.photos', name: 'Photos' },
  { packageName: 'demo.settings', name: 'Settings' },
  { packageName: 'demo.youtube', name: 'YouTube' },
];
