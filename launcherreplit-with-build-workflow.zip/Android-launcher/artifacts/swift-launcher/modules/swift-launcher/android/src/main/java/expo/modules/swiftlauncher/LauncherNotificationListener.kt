package expo.modules.swiftlauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Build
import java.util.concurrent.ConcurrentHashMap

class LauncherNotificationListener : NotificationListenerService() {
  override fun onListenerConnected() {
    activeNotifications?.forEach { updateMediaController(it) }
  }

  override fun onNotificationPosted(sbn: StatusBarNotification) {
    updateMediaController(sbn)
    val enabled = getSharedPreferences("swift_launcher", MODE_PRIVATE)
      .getBoolean("notification_previews_enabled", false)
    if (!enabled) return
    val title = sbn.notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
      ?.takeIf { it.isNotBlank() } ?: return
    previews[sbn.packageName] = title.take(120)
  }

  override fun onNotificationRemoved(sbn: StatusBarNotification) {
    val current = activeMediaPackage
    if (current == sbn.packageName) {
      activeMediaController = null
      activeMediaPackage = null
      activeMediaTitle = null
      activeMediaArtist = null
      activeMediaPlaying = false
    }
  }

  private fun updateMediaController(sbn: StatusBarNotification) {
    try {
      val token: android.media.session.MediaSession.Token? = if (Build.VERSION.SDK_INT >= 33) {
        sbn.notification.extras.getParcelable(Notification.EXTRA_MEDIA_SESSION, android.media.session.MediaSession.Token::class.java)
      } else {
        @Suppress("DEPRECATION")
        sbn.notification.extras.getParcelable(Notification.EXTRA_MEDIA_SESSION)
      }
      if (token != null) {
        val controller = MediaController(this, token)
        val metadata = controller.metadata
        activeMediaController = controller
        activeMediaPackage = sbn.packageName
        activeMediaTitle = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
          ?: sbn.notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        activeMediaArtist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
          ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
          ?: sbn.notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        activeMediaPlaying = controller.playbackState?.state == PlaybackState.STATE_PLAYING
      }
    } catch (_: Exception) { }
  }

  companion object {
    val previews = ConcurrentHashMap<String, String>()
    @Volatile var activeMediaController: MediaController? = null
    @Volatile var activeMediaPackage: String? = null
    @Volatile var activeMediaTitle: String? = null
    @Volatile var activeMediaArtist: String? = null
    @Volatile var activeMediaPlaying: Boolean = false
  }
}
