# Build a downloadable Android APK on GitHub Actions

This repository includes `.github/workflows/build.yml`. It installs the pnpm workspace dependencies, builds the Android release variant, and uploads the APK as a GitHub Actions artifact.

## Steps

1. Extract this project ZIP.
2. Create a GitHub repository and push the **contents of the `Android-launcher` folder** to the repository root. The `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `package.json`, and `artifacts/` folder must all be at the repository root level as they are in this ZIP.
3. In GitHub, open **Actions** and enable workflows if GitHub asks.
4. Select **Build Android APK** in the workflow list.
5. Click **Run workflow** and run it on your branch. It also runs on pushes to `main` or `master` when the listed project paths change.
6. Wait for the job to finish successfully. Open that workflow run and find **Artifacts** near the bottom.
7. Download `swift-launcher-release-apk.zip`, extract it, and install `app-release.apk` on your Android phone. You may need to allow installation from your browser or file manager.

## Notes

- This workflow builds the APK; it does not publish a GitHub Release.
- The current Gradle project config signs the release variant with the project's debug keystore. This is convenient for personal testing, but it is **not suitable for Play Store publishing or secure long-term update signing**. Use a private release keystore stored as GitHub Actions secrets before distributing broadly.
- The workflow does not guarantee that the source compiles. If the build fails, open the failed `Build release APK` step and use the first Gradle error to identify the issue.
