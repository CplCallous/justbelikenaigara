# Swift Launcher — feature implementation progress

This iteration implements the first group of previously placeholder-only features.

## Implemented in this iteration

- **Calendar agenda:** Android native module queries upcoming calendar instances for the next 14 days. The home card displays up to three upcoming events. Calendar permission is requested only when the calendar feature is enabled.
- **Calendar preview:** The app drawer can show the next two calendar events.
- **Weather card:** Uses Android foreground location permission and Open-Meteo's current conditions endpoint. If permission or the network is unavailable, the card shows a retry state rather than a fake forecast.
- **Media controls:** Uses media session tokens surfaced through Android notification listener access. The home card shows track/artist when available and sends play/pause/previous/next commands to the active session.
- **Notification summary:** Adds a compact home card using notification titles captured by the existing notification listener. Notification access must be enabled by the user.
- **Digital wellbeing summary:** Reads today's foreground time per app through Android UsageStatsManager. Usage access must be enabled in Android Settings.

## Previously included UI fixes retained

- Search does not auto-focus when opening the app drawer.
- Alphabet scrubber supports drag-to-scroll while preserving letter taps.
- Rename dialog is keyboard-aware and Android Back closes the dialog first.
- PIN protection can be disabled from security settings after confirmation.
- Clock text size is adjustable and saved with launcher preferences.

## Still pending

These features are not claimed as implemented yet:

1. Native Android app-widget hosting, picker, and per-widget resizing/placement.
2. Reliable quick-reply actions through notification `RemoteInput`.
3. Actual icon-pack discovery and applying third-party pack resources.
4. Per-app swipe actions and floating/pop-up app windows.
5. Work-profile / dual-app separation and Bluetooth-triggered shortcuts.
6. Sesame integration and a Google News feed.
7. A properly scheduled break-reminder system that works when the launcher is backgrounded.
8. Full device build, runtime QA, and crash testing.

## Verification status

- TypeScript/TSX syntax transpilation passed for the modified screen and native bridge files.
- A complete TypeScript typecheck and Android Kotlin build could not be run in this environment: dependencies are not installed and the Gradle wrapper could not download its distribution because network access was unavailable.
- Test calendar permission, location permission, notification listener access, and usage access on a device before release. Android OEM behavior may differ.
