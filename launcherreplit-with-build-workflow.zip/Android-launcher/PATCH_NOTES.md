# Launcher UI and interaction patch

## Included in this patch

- App drawer search no longer steals focus or opens the keyboard automatically.
- Alphabet scrubber supports both tapping a letter and dragging through the letters. It no longer captures a tap at touch-down, and section navigation is guarded against stale list positions.
- Rename and other in-app dialogs are keyboard-aware and scroll when space is limited. Android Back closes an open dialog before navigating away; it also closes the app action sheet before leaving the current screen.
- Added a persisted home-clock size control in Settings (28–72 px). The chosen size is saved with launcher preferences.
- Added a clearly labelled **Disable PIN protection** action. After confirmation, it removes the PIN, clears app locks, and converts private folders into ordinary visible folders without deleting their contents.

## Existing gesture behavior

- Swipe up from the home screen opens the app drawer.
- Swipe down only attempts to open the notification shade when that setting is enabled; it does not open search.

## Features still requiring separate implementation

The source contains settings toggles for features that are not implemented in this build, including Android app-widget hosting, icon-pack discovery, calendar/weather data cards, media-session controls, notification quick replies and summaries, headphone/Bluetooth triggers, work-profile/dual-app grouping, pop-up app windows, and Sesame/Google News integrations. These require additional native Android APIs, permissions, providers, or service integrations; this patch does not falsely mark those features as implemented.

## Validation note

The source changes were reviewed for structural consistency, but a full TypeScript/Android build could not be run in this environment because the workspace dependencies are not installed and the package registry was unreachable. Build and install the Android app in the original development environment before replacing the installed APK.
